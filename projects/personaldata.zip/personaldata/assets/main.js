console.log("hello");

let onesection = document.querySelector("#one");
let twosection = document.querySelector("#two");
let oneImg = document.querySelector(".oneimg");
let twoImg = document.querySelector(".twoimg");
let time = document.querySelector(".time");
let timeTwo = document.querySelector(".timetwo");

function showImgOne() {
	if (oneImg.style.display == "none") {
		oneImg.style.display = "";
	} else {
		oneImg.style.display = "none"
	}
}
function showTime() {
	if (time.style.display == "none") {
		time.style.display = "";
	} else {
		time.style.display = "none"
	}
}

function showImgTwo() {
	if (twoImg.style.display == "none") {
		twoImg.style.display = "";
	} else {
		twoImg.style.display = "none"
	}
}
function showTimeTwo() {
	if (timeTwo.style.display == "none") {
		timeTwo.style.display = "";
	} else {
		timeTwo.style.display = "none"
	}
}

onesection.addEventListener("click", showImgOne);
onesection.addEventListener("click", showTime);

twosection.addEventListener("click", showImgTwo);
twosection.addEventListener("click", showTimeTwo);